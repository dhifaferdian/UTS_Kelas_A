<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
namespace Codecademy;

// Write your code below:
$hybrid_array = array("first element", "second element","zainal","arifin");
$hybrid_array[3] =  "empat lagi";
//kelas A
