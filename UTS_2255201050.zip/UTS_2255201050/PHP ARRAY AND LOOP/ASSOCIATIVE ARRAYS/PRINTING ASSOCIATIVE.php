<?php
namespace Codecademy;
//MUHAMMAD DHIFA FERDIAN
//2255201050

// Write your code below:
$september_hits = ["The Sixth Sense" => 22896967,
"Stigmata" => 18309666,
"Blue Streak" => 19208806,
"Double Jeopardy" => 23162542];

echo implode(", ", $september_hits);

print_r($september_hits);
//kelas A