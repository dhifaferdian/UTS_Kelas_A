<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
//Kelas A
namespace Codecademy;

// Write your code below:
echo getrandmax();
echo "\n";
echo rand();
echo "\n";
echo rand(1, 999);