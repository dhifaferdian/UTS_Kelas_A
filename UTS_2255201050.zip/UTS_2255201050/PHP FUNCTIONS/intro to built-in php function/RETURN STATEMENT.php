<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
//Kelas A
 function printStringReturnNumber()
 {
  echo "eleven";
  return 11;
 }


 $my_num = printStringReturnNumber();
 echo $my_num = 11;