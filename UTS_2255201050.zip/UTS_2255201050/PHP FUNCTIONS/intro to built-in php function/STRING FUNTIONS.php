<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
//Kelas A
namespace Codecademy;

// Write your code below:
echo strrev("Perkenalkan Saya Mahasiswa,\n");

echo strtolower("\nDari Prodi S1 Teknik informatika");

echo str_repeat("\nUniversitas Pahlawan Tuanku Tambusai.\n", 9);
