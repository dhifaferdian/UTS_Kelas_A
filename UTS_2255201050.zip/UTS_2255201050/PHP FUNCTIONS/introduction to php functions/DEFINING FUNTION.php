<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
//Kelas A
// Write your code below:
function praisePHP()
{
 echo "rian.epe";
}
  
  
  
  
  
  
  
  
  
  
  