<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
//Kelas A
// Write your code below:
  function inflateEgo()
  {
    echo "Hello, People!\n";
  }

 inflateEgo();
 /*
 Prints:
 Hello, People
 */
 inflateEgo();