<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
//Kelas A
// Write your code below:
function calculateArea($tinggi, $lebar)
{
  return $tinggi * $lebar;
}

function calculateVolume($tinggi, $lebar, $dalam)
{
  return $tinggi * $lebar * $dalam;
}  

echo calculateArea(5, 10);
echo "\n";
echo calculateVolume(4, 11, 7);