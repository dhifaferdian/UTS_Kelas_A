<?php
//MUHAMMAD DHIFA FERDIAN 
//2255201050
//Kelas A
function first()
{
  return "You did it!\n";
}

function second()
{
  return "You're amazing!\n";
}

function third()
{
  return "You're a coding hero!\n";
}

echo first() . " " . second() . " " . third();