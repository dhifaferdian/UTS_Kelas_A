<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
// Write your code below:
 echo 11 + 1; 
//Kelas A 
  
  
  


