<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
// Write your code below:
  
 echo 8 ** 2; 
//Kelas A
  

