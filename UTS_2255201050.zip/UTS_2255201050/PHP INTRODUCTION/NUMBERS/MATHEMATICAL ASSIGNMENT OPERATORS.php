<?php
////MUHAMMAD DHIFA FERDIAN
//2255201050
// Write your code below:

 $my_num = -190.82; 
 $answer = $my_num;
 $answer += 2;
 $answer *= 2;
 $answer -= 2;
 $answer /= 2;
 $answer -= $my_num;
 echo $answer;
 //kelas A 
  
  
  
  
  
  
  
  
  
