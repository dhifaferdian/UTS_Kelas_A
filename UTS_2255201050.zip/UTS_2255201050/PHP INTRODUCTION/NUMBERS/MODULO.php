<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
// Write your code below:
  
 echo 82 % 6; 
 //Kelas A 
  


