<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
// Write your code below:
  
$num_languages = 4;
$months = 11;
$days = 16;
$a = $num_languages / $months *$days;
echo $a;  
 //kelas A 



