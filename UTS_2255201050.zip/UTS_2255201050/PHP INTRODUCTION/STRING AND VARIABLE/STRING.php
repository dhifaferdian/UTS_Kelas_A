<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
echo "Hello World!";
//Kelas A
?>
  
  


