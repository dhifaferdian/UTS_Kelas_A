<?php
//MUHAMMAD DHIFA FERDIAN
//2255201050
$name = "Halo, saya variabel!";
$language = "Oh hai. Saya juga variabel.";  
$name = "variabel";
  echo "Saya suka bersambung" . $name;  
$language = "burger";
  echo "\nSaya suka " . $language;
  //kelas A
  


